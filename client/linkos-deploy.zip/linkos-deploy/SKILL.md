---
name: linkos-deploy
description: Automated production deployment for WeChat Private Domain Live Code System (LinkOS). Use this skill when deploying code updates to the production server, including backend Docker container updates and frontend static file deployments. This skill handles the complete deployment workflow: building AMD64 Docker images, updating client environment configuration, syncing files to the server via SSH, managing Docker containers, and deploying frontend files to the Baota panel web directory.
---

# LinkOS Production Deployment

## Overview

This skill automates the production deployment workflow for the WeChat Private Domain Live Code System (LinkOS). It handles both backend (Docker container) and frontend (static files) deployment to a Tencent Cloud server running Baota panel.

The deployment process:
1. Updates frontend API configuration
2. Builds frontend for production
3. Builds AMD64 Docker image for backend
4. Transfers Docker image to server
5. Updates Docker container on server
6. Deploys frontend to Baota web directory
7. Verifies deployment success

## When to Use This Skill

Use this skill when:
- Code changes need to be deployed to production
- Backend API endpoints have been modified
- Frontend UI components have been updated
- New features need to be released
- Bug fixes need to be pushed to production

## Prerequisites

- SSH access to production server: `root@193.112.10.112`
- SSH key located at: `/Users/lhong/code/.ssh/bt.wx11.top_id_rsa`
- Docker installed locally
- Project structure:
  - Backend: `/Users/lhong/code/huoma/server`
  - Frontend: `/Users/lhong/code/huoma/client`

## Deployment Workflow

### Quick Deployment

Execute the automated deployment script:

```bash
/Users/lhong/code/.claude/skills/linkos-deploy/scripts/deploy.sh
```

This script performs all deployment steps automatically.

### Manual Deployment Steps

If manual control is needed, follow these steps:

#### Step 1: Update Frontend Configuration

Update the frontend API URL to point to production:

```bash
sed -i '' 's|VITE_API_BASE_URL=.*|VITE_API_BASE_URL=https://hm.wx11.top|' /Users/lhong/code/huoma/client/.env
```

#### Step 2: Build Frontend

```bash
cd /Users/lhong/code/huoma/client
npm run build
```

#### Step 3: Build Backend Docker Image (AMD64)

```bash
cd /Users/lhong/code/huoma/server
docker rmi linkos-server:latest 2>/dev/null || true
docker buildx build \
  --platform linux/amd64 \
  --build-arg BUILD_ID=$(date +"%Y%m%d-%H%M%S") \
  -t linkos-server:latest \
  .
```

#### Step 4: Transfer Docker Image to Server

```bash
BUILD_ID=$(date +"%Y%m%d-%H%M%S")
docker save linkos-server:latest -o /tmp/linkos-server-amd64-${BUILD_ID}.tar
scp -i /Users/lhong/code/.ssh/bt.wx11.top_id_rsa \
  /tmp/linkos-server-amd64-${BUILD_ID}.tar \
  root@193.112.10.112:/tmp/
rm -f /tmp/linkos-server-amd64-${BUILD_ID}.tar
```

#### Step 5: Update Docker Container on Server

```bash
ssh -i /Users/lhong/code/.ssh/bt.wx11.top_id_rsa root@193.112.10.112 << 'ENDSSH'
docker rm -f linkos-server
docker load -i /tmp/linkos-server-amd64-*.tar
rm -f /tmp/linkos-server-amd64-*.tar

docker run -d \
  --name linkos-server \
  -p 3001:3001 \
  -v /data/linkos-server/data:/app/data \
  -v /data/linkos-server/uploads:/app/uploads \
  -e PORT=3001 \
  -e ADMIN_PASSWORD=admin \
  -e JWT_SECRET=linkos-jwt-secret-2026 \
  -e OSS_ENABLED=true \
  -e OSS_ENDPOINT=oss-cn-shenzhen.aliyuncs.com \
  -e OSS_BUCKET=lhong \
  -e OSS_BUCKET_PATH_PREFIX=wxhm \
  -e OSS_ACCESS_KEY_ID=LTAI5tLcyUtK1rVmgv6isW97 \
  -e OSS_ACCESS_KEY_SECRET=5miSCOJIkWu1uEG2CS4bMulc50b2LH \
  --restart unless-stopped \
  linkos-server:latest
ENDSSH
```

#### Step 6: Deploy Frontend to Baota

```bash
rsync -avz --delete \
  -e "ssh -i /Users/lhong/code/.ssh/bt.wx11.top_id_rsa" \
  /Users/lhong/code/huoma/client/dist/ \
  root@193.112.10.112:/www/dk_project/wwwroot/hm.wx11.top/
```

#### Step 7: Verify Deployment

```bash
ssh -i /Users/lhong/code/.ssh/bt.wx11.top_id_rsa root@193.112.10.112 << 'ENDSSH'
# Check container status
docker ps | grep linkos-server

# Check health endpoint
curl -s http://localhost:3001/health

# Check API login
curl -s -X POST https://hm.wx11.top/api/admin/login \
  -H "Content-Type: application/json" \
  -d '{"password":"admin"}'

# Check frontend
curl -s -o /dev/null -w "HTTP: %{http_code}\n" https://hm.wx11.top/
ENDSSH
```

## Troubleshooting

### Container Won't Start

Check container logs for errors:
```bash
ssh -i /Users/lhong/code/.ssh/bt.wx11.top_id_rsa root@193.112.10.112 "docker logs linkos-server"
```

### API Returns 404

Verify Nginx configuration and reload:
```bash
ssh -i /Users/lhong/code/.ssh/bt.wx11.top_id_rsa root@193.112.10.112 "nginx -t && nginx -s reload"
```

### Frontend Not Updating

Clear browser cache or verify files were synced:
```bash
ssh -i /Users/lhong/code/.ssh/bt.wx11.top_id_rsa root@193.112.10.112 "ls -la /www/dk_project/wwwroot/hm.wx11.top/"
```

## Resources

### scripts/deploy.sh
Automated deployment script that performs all deployment steps. Execute directly for one-command deployment.

### references/deployment-reference.md
Complete reference documentation including:
- Server connection details
- Container configuration
- Environment variables
- Domain configuration
- Common commands
- Troubleshooting guide

### assets/nginx-site.conf
Nginx configuration template for new domains in the domain pool. Replace `DOMAIN_NAME` placeholder with actual domain name.
