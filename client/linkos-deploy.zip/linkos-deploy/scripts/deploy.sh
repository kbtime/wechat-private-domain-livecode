#!/bin/bash
set -e

PROJECT_ROOT="/Users/lhong/code/huoma"
SERVER="root@193.112.10.112"
SSH_KEY="/Users/lhong/code/.ssh/bt.wx11.top_id_rsa"
BUILD_ID=$(date +"%Y%m%d-%H%M%S")
IMAGE_NAME="linkos-server:latest"
IMAGE_FILE="/tmp/linkos-server-amd64-${BUILD_ID}.tar"

# 环境变量
export OSS_ENABLED=true
export OSS_ENDPOINT=oss-cn-shenzhen.aliyuncs.com
export OSS_BUCKET=lhong
export OSS_BUCKET_PATH_PREFIX=wxhm
export OSS_ACCESS_KEY_ID=LTAI5tLcyUtK1rVmgv6isW97
export OSS_ACCESS_KEY_SECRET=5miSCOJIkWu1uEG2CS4bMulc50b2LH

echo "======================================"
echo "  LinkOS 生产部署 - ${BUILD_ID}"
echo "======================================"

# 步骤 1: 更新前端 API URL
echo ""
echo "[1/6] 更新前端 API URL..."
sed -i '' 's|VITE_API_BASE_URL=.*|VITE_API_BASE_URL=https://hm.wx11.top|' "${PROJECT_ROOT}/client/.env"

# 步骤 2: 构建前端
echo ""
echo "[2/6] 构建前端..."
cd "${PROJECT_ROOT}/client"
npm run build

# 步骤 3: 构建 AMD64 Docker 镜像
echo ""
echo "[3/6] 构建 AMD64 Docker 镜像..."
cd "${PROJECT_ROOT}/server"
docker rmi ${IMAGE_NAME} 2>/dev/null || true
docker buildx build \
  --platform linux/amd64 \
  --build-arg BUILD_ID=${BUILD_ID} \
  -t ${IMAGE_NAME} \
  .

# 步骤 4: 打包并上传镜像
echo ""
echo "[4/6] 上传 Docker 镜像..."
docker save ${IMAGE_NAME} -o ${IMAGE_FILE}
scp -i ${SSH_KEY} ${IMAGE_FILE} ${SERVER}:/tmp/
rm -f ${IMAGE_FILE}

# 步骤 5: 更新服务器容器
echo ""
echo "[5/6] 更新服务器容器..."
ssh -i ${SSH_KEY} ${SERVER} << 'ENDSSH'
set -e
docker rm -f linkos-server 2>/dev/null || true
docker load -i /tmp/linkos-server-amd64-*.tar
rm -f /tmp/linkos-server-amd64-*.tar

docker run -d \
  --name linkos-server \
  -p 3001:3001 \
  -v /data/linkos-server/data:/app/data \
  -v /data/linkos-server/uploads:/app/uploads \
  -e PORT=3001 \
  -e ADMIN_PASSWORD=admin \
  -e JWT_SECRET=linkos-jwt-secret-2026 \
  -e OSS_ENABLED=true \
  -e OSS_ENDPOINT=oss-cn-shenzhen.aliyuncs.com \
  -e OSS_BUCKET=lhong \
  -e OSS_BUCKET_PATH_PREFIX=wxhm \
  -e OSS_ACCESS_KEY_ID=LTAI5tLcyUtK1rVmgv6isW97 \
  -e OSS_ACCESS_KEY_SECRET=5miSCOJIkWu1uEG2CS4bMulc50b2LH \
  --restart unless-stopped \
  linkos-server:latest

sleep 5
ENDSSH

# 步骤 6: 部署前端到宝塔
echo ""
echo "[6/6] 部署前端..."
rsync -avz --delete \
  -e "ssh -i ${SSH_KEY}" \
  "${PROJECT_ROOT}/client/dist/" \
  ${SERVER}:/www/dk_project/wwwroot/hm.wx11.top/

# 步骤 7: 验证部署
echo ""
echo "======================================"
echo "  验证部署"
echo "======================================"
ssh -i ${SSH_KEY} ${SERVER} << 'ENDSSH'
echo "容器状态:"
docker ps | grep linkos-server

echo ""
echo "版本号:"
docker exec linkos-server cat /app/build_version.txt

echo ""
echo "健康检查:"
curl -s http://localhost:3001/health

echo ""
echo "API 登录:"
curl -s -X POST https://hm.wx11.top/api/admin/login \
  -H "Content-Type: application/json" \
  -d '{"password":"admin"}' | head -100

echo ""
echo "前端首页:"
curl -s -o /dev/null -w "HTTP: %{http_code}\n" https://hm.wx11.top/

ENDSSH

echo ""
echo "======================================"
echo "  部署完成!"
echo "  版本: ${BUILD_ID}"
echo "======================================"
