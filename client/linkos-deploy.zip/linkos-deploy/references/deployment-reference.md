# LinkOS 生产环境部署参考文档

## 服务器信息

- **服务器地址**: 193.112.10.112 (腾讯云)
- **SSH 认证**: `/Users/lhong/code/.ssh/bt.wx11.top_id_rsa`
- **登录用户**: root
- **面板类型**: 宝塔面板

## 服务配置

### Docker 容器

- **容器名称**: linkos-server
- **镜像名称**: linkos-server:latest
- **内部端口**: 3001
- **外部端口**: 3001

### 数据持久化

- **数据目录**: `/data/linkos-server/data`
- **上传目录**: `/data/linkos-server/uploads`

### 环境变量

```bash
PORT=3001
ADMIN_PASSWORD=admin
JWT_SECRET=linkos-jwt-secret-2026
OSS_ENABLED=true
OSS_ENDPOINT=oss-cn-shenzhen.aliyuncs.com
OSS_BUCKET=lhong
OSS_BUCKET_PATH_PREFIX=wxhm
OSS_ACCESS_KEY_ID=LTAI5tLcyUtK1rVmgv6isW97
OSS_ACCESS_KEY_SECRET=5miSCOJIkWu1uEG2CS4bMulc50b2LH
```

## 域名配置

### 管理后台域名

- **域名**: hm.wx11.top
- **类型**: HTTPS (SSL 已配置)
- **前端目录**: `/www/dk_project/wwwroot/hm.wx11.top`
- **Nginx 配置**: `/www/server/panel/vhost/nginx/hm.wx11.top.conf`

### Nginx 配置要点

```nginx
# API 接口 - 代理到后端
location /api/ {
    proxy_pass http://127.0.0.1:3001;
    proxy_set_header Host $http_host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}

# H5 页面 - 代理到后端
location /h5/ {
    proxy_pass http://127.0.0.1:3001;
    proxy_set_header Host $http_host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}

# 前端静态文件 (SPA 路由支持)
location / {
    try_files $uri $uri/ /index.html;
}
```

## 常用命令

### 容器管理

```bash
# 查看容器状态
docker ps | grep linkos-server

# 查看容器日志
docker logs -f linkos-server

# 重启容器
docker restart linkos-server

# 停止容器
docker stop linkos-server

# 进入容器
docker exec -it linkos-server sh
```

### Nginx 管理

```bash
# 检查配置
nginx -t

# 重载配置
nginx -s reload

# 重启 Nginx
systemctl restart nginx

# 查看错误日志
tail -f /www/wwwlogs/hm.wx11.top.error.log
```

## 故障排查

### 容器无法启动

```bash
# 查看详细错误日志
docker logs linkos-server

# 检查端口占用
lsof -i:3001

# 检查数据目录权限
ls -la /data/linkos-server/
```

### API 无法访问

```bash
# 检查容器是否运行
docker ps | grep linkos-server

# 测试本地连接
curl http://localhost:3001/health

# 检查 Nginx 配置
cat /www/server/panel/vhost/nginx/hm.wx11.top.conf

# 重载 Nginx
nginx -s reload
```

### 前端页面无法访问

```bash
# 检查前端文件
ls -la /www/dk_project/wwwroot/hm.wx11.top/

# 检查文件权限
chown -R www:www /www/dk_project/wwwroot/hm.wx11.top/

# 检查 Nginx 错误日志
tail -50 /www/wwwlogs/hm.wx11.top.error.log
```

## 部署验证清单

- [ ] Docker 容器运行正常
- [ ] 健康检查返回 200: `curl http://localhost:3001/health`
- [ ] API 登录正常: `curl https://hm.wx11.top/api/admin/login`
- [ ] 前端首页可访问: `curl https://hm.wx11.top/`
- [ ] H5 页面可访问: `curl https://hm.wx11.top/h5/landing.html`
- [ ] 版本号正确: `docker exec linkos-server cat /app/build_version.txt`
