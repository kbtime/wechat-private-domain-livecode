
import React, { useState, useEffect } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';
import { Plus, Settings2, ShieldCheck, Database, QrCode as QrIcon } from 'lucide-react';
import { Layout } from './components/Layout';
import { LiveCodeCard } from './components/LiveCodeCard';
import { PromotionModal } from './components/PromotionModal';
import { CreateEditDrawer } from './components/CreateEditDrawer';
import { LiveCode } from './types';
import { MOCK_LIVE_CODES, CHART_DATA } from './constants';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [activeView, setActiveView] = useState('live-codes');
  const [liveCodes, setLiveCodes] = useState<LiveCode[]>(MOCK_LIVE_CODES);
  const [selectedCode, setSelectedCode] = useState<LiveCode | null>(null);
  const [showPromote, setShowPromote] = useState(false);
  const [showDrawer, setShowDrawer] = useState(false);
  const [drawerData, setDrawerData] = useState<LiveCode | undefined>(undefined);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'admin') {
      setIsAuthenticated(true);
    } else {
      alert('密码错误');
    }
  };

  const openEditDrawer = (code: LiveCode) => {
    setDrawerData(code);
    setShowDrawer(true);
  };

  const openCreateDrawer = () => {
    setDrawerData(undefined);
    setShowDrawer(true);
  };

  const openPromoteModal = (code: LiveCode) => {
    setSelectedCode(code);
    setShowPromote(true);
  };

  const handleSave = (newData: Partial<LiveCode>) => {
    // Mock save logic
    if (newData.id) {
       setLiveCodes(prev => prev.map(c => c.id === newData.id ? { ...c, ...newData } as LiveCode : c));
    } else {
       const newCode = {
         ...newData,
         id: `code-${Date.now()}`,
         status: 'running',
         totalPv: 0,
         mainUrl: `https://caoliao.api/link?id=${Date.now()}`,
       } as LiveCode;
       setLiveCodes(prev => [newCode, ...prev]);
    }
    setShowDrawer(false);
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-sm bg-white rounded-2xl shadow-xl overflow-hidden animate-in fade-in zoom-in duration-300">
          <div className="p-8 pb-4 flex flex-col items-center">
            <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-blue-200">
               <ShieldCheck className="text-white w-10 h-10" />
            </div>
            <h1 className="text-3xl font-extrabold text-blue-600 tracking-tight">Admin Dashboard</h1>
            <p className="text-gray-400 mt-2 text-sm">请输入管理密码以继续</p>
          </div>
          
          <form onSubmit={handleLogin} className="p-8 pt-4">
            <div className="space-y-4">
              <div className="relative">
                <input 
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-5 py-4 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all pr-12 font-mono"
                  placeholder="请输入管理密码"
                />
                <Settings2 className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-300 w-5 h-5" />
              </div>
              <button 
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold text-lg transition-all active:scale-[0.98] shadow-lg shadow-blue-200"
              >
                登录系统
              </button>
            </div>
          </form>

          <div className="bg-gray-50 p-4 border-t border-gray-100 flex justify-center">
             <span className="text-xs text-gray-400 font-mono">Powered by JSON-LiveCode v1.0</span>
          </div>
        </div>
      </div>
    );
  }

  const renderDashboard = () => (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { label: '总访问 PV', value: '5,269', change: '+12%', color: 'blue' },
          { label: '活跃活码', value: '24', change: '+2', color: 'green' },
          { label: '今日新增', value: '458', change: '+8%', color: 'purple' },
          { label: '平均转化率', value: '18.5%', change: '-2%', color: 'orange' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <p className="text-sm text-gray-400 font-medium mb-1">{stat.label}</p>
            <div className="flex items-end justify-between">
              <h3 className="text-2xl font-bold text-gray-800">{stat.value}</h3>
              <span className={`text-xs font-bold px-2 py-0.5 rounded ${stat.change.startsWith('+') ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'}`}>
                {stat.change}
              </span>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold text-gray-800 mb-6">访问趋势分析</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={CHART_DATA}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                />
                <Line type="monotone" dataKey="pv" stroke="#2563eb" strokeWidth={3} dot={{ r: 4, fill: '#2563eb' }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold text-gray-800 mb-6">流量分布</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={CHART_DATA}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                />
                <Bar dataKey="uv" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );

  const renderLiveCodes = () => (
    <div className="animate-in fade-in duration-500">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-bold text-gray-800">我的活码</h2>
        <div className="flex items-center space-x-3">
           <button className="flex items-center space-x-2 px-4 py-2 bg-white text-gray-600 rounded-lg border border-gray-200 hover:bg-gray-50 font-medium shadow-sm transition-all">
             <Settings2 className="w-4 h-4" />
             <span>域名池配置</span>
           </button>
           <button 
            onClick={openCreateDrawer}
            className="flex items-center space-x-2 px-5 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-bold shadow-lg shadow-blue-200 transition-all active:scale-95"
           >
             <Plus className="w-5 h-5" />
             <span>新建活码</span>
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-6">
        {liveCodes.map(code => (
          <LiveCodeCard 
            key={code.id} 
            code={code} 
            onEdit={openEditDrawer}
            onPromote={openPromoteModal}
            onStats={(c) => setActiveView('stats')}
          />
        ))}
        
        {/* Empty State / Add Placeholder */}
        <button 
          onClick={openCreateDrawer}
          className="border-2 border-dashed border-gray-200 rounded-xl p-8 flex flex-col items-center justify-center text-gray-400 hover:border-blue-300 hover:text-blue-400 transition-all bg-white/50"
        >
          <div className="w-12 h-12 bg-gray-50 rounded-full flex items-center justify-center mb-3 group-hover:bg-blue-50">
            <Plus className="w-8 h-8" />
          </div>
          <span className="font-bold">新建活码</span>
        </button>
      </div>
    </div>
  );

  return (
    <Layout 
      activeView={activeView} 
      onViewChange={setActiveView}
      onLogout={() => setIsAuthenticated(false)}
    >
      {activeView === 'dashboard' && renderDashboard()}
      {activeView === 'live-codes' && renderLiveCodes()}
      {activeView === 'stats' && <div className="text-center py-20 text-gray-400 italic">统计报表正在开发中...</div>}
      {activeView === 'settings' && <div className="text-center py-20 text-gray-400 italic">系统设置正在开发中...</div>}
      {activeView === 'users' && <div className="text-center py-20 text-gray-400 italic">用户管理正在开发中...</div>}

      {showPromote && selectedCode && (
        <PromotionModal code={selectedCode} onClose={() => setShowPromote(false)} />
      )}

      {showDrawer && (
        <CreateEditDrawer 
          code={drawerData} 
          onClose={() => setShowDrawer(false)} 
          onSave={handleSave}
        />
      )}
    </Layout>
  );
};

export default App;
