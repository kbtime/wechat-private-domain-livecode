
import React, { useState } from 'react';
import { X, Upload, Trash2, ArrowUp, Plus, ChevronRight } from 'lucide-react';
import { LiveCode, DistributionMode, SubCode } from '../types';

interface CreateEditDrawerProps {
  code?: LiveCode;
  onClose: () => void;
  onSave: (code: Partial<LiveCode>) => void;
}

export const CreateEditDrawer: React.FC<CreateEditDrawerProps> = ({ code, onClose, onSave }) => {
  const [formData, setFormData] = useState<Partial<LiveCode>>(code || {
    name: '',
    distributionMode: DistributionMode.THRESHOLD,
    subCodes: [
      { id: 'new-1', qrUrl: 'https://picsum.photos/100', threshold: 100, currentPv: 0, weight: 1, status: 'enabled' }
    ]
  });

  const addSubCode = () => {
    setFormData(prev => ({
      ...prev,
      subCodes: [
        ...(prev.subCodes || []),
        { 
          id: `new-${Date.now()}`, 
          qrUrl: 'https://picsum.photos/100', 
          threshold: 100, 
          currentPv: 0, 
          weight: 1, 
          status: 'enabled' 
        }
      ]
    }));
  };

  const removeSubCode = (id: string) => {
    setFormData(prev => ({
      ...prev,
      subCodes: (prev.subCodes || []).filter(s => s.id !== id)
    }));
  };

  return (
    <div className="fixed inset-0 z-[100] flex justify-end">
      <div className="absolute inset-0 bg-black/30 backdrop-blur-[2px]" onClick={onClose} />
      <div className="relative w-full max-w-2xl bg-white h-full shadow-2xl flex flex-col animate-in slide-in-from-right duration-300">
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <h2 className="text-xl font-bold text-gray-800">{code ? '编辑活码' : '新建活码'}</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full">
            <X className="w-6 h-6 text-gray-400" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-8 space-y-10">
          {/* Basic Info */}
          <section>
            <div className="flex items-center space-x-2 text-blue-600 font-bold mb-6">
              <span className="w-6 h-6 rounded-full border-2 border-blue-600 flex items-center justify-center text-sm">A</span>
              <h3>基本信息</h3>
            </div>
            
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">活码名称</label>
                <input 
                  type="text" 
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  placeholder="请输入活码名称"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">分流模式</label>
                <div className="flex flex-wrap gap-3">
                  {[
                    { mode: DistributionMode.THRESHOLD, label: '阈值切换', icon: '🔀' },
                    { mode: DistributionMode.RANDOM, label: '随机展示', icon: '🔁' },
                    { mode: DistributionMode.FIXED, label: '固定一张', icon: '⚓' }
                  ].map(m => (
                    <button
                      key={m.mode}
                      onClick={() => setFormData({...formData, distributionMode: m.mode})}
                      className={`flex items-center space-x-2 px-5 py-3 rounded-xl border-2 transition-all ${
                        formData.distributionMode === m.mode 
                          ? 'border-blue-600 bg-blue-50 text-blue-700' 
                          : 'border-gray-100 hover:border-gray-200'
                      }`}
                    >
                      <span>{m.icon}</span>
                      <span className="font-medium">{m.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </section>

          {/* Sub Code Management */}
          <section>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-2 text-blue-600 font-bold">
                <span className="w-6 h-6 rounded-full border-2 border-blue-600 flex items-center justify-center text-sm">B</span>
                <h3>子码管理</h3>
              </div>
              <button 
                onClick={addSubCode}
                className="flex items-center space-x-1 text-sm text-blue-600 font-medium hover:underline"
              >
                <Plus className="w-4 h-4" />
                <span>添加子码</span>
              </button>
            </div>

            <div className="bg-blue-50/50 border-2 border-dashed border-blue-200 rounded-2xl p-8 mb-6 flex flex-col items-center justify-center text-center">
               <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm mb-3">
                 <Upload className="w-6 h-6 text-blue-500" />
               </div>
               <p className="font-bold text-gray-700">点击或拖拽上传二维码</p>
               <p className="text-xs text-gray-400 mt-1">支持 JPG, PNG 格式，文件大小不超过 5MB</p>
            </div>

            <div className="space-y-4">
              {formData.subCodes?.map((sub, idx) => (
                <div key={sub.id} className="flex items-center space-x-4 p-4 bg-white border border-gray-100 rounded-xl shadow-sm">
                  <div className="w-16 h-16 bg-gray-50 rounded border flex items-center justify-center p-1 group relative">
                    <img src={sub.qrUrl} className="w-full h-full object-cover rounded" />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity rounded">
                      <span className="text-[10px] text-white">点击放大</span>
                    </div>
                  </div>
                  
                  <div className="flex-1 grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase font-bold mb-1">阈值</label>
                      <input 
                        type="number" 
                        value={sub.threshold}
                        className="w-full px-3 py-2 border border-gray-100 rounded focus:border-blue-400 outline-none text-sm"
                        placeholder="例如 200"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-400 uppercase font-bold mb-1">状态</label>
                      <div className="flex items-center h-[38px]">
                        <button className={`w-10 h-5 rounded-full relative transition-colors ${sub.status === 'enabled' ? 'bg-blue-500' : 'bg-gray-300'}`}>
                          <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-transform ${sub.status === 'enabled' ? 'right-1' : 'left-1'}`} />
                        </button>
                        <span className="ml-2 text-xs text-gray-500">{sub.status === 'enabled' ? '开启' : '禁用'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <button onClick={() => removeSubCode(sub.id)} className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded">
                      <Trash2 className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-gray-400 hover:text-blue-500 hover:bg-blue-50 rounded">
                      <ArrowUp className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>

        <div className="p-6 border-t border-gray-100 flex items-center justify-end space-x-4">
          <button 
            onClick={onClose}
            className="px-6 py-2.5 rounded-lg border border-gray-200 text-gray-600 font-medium hover:bg-gray-50 transition-colors"
          >
            取消
          </button>
          <button 
            onClick={() => onSave(formData)}
            className="px-8 py-2.5 rounded-lg bg-blue-600 text-white font-bold hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200"
          >
            保存配置
          </button>
        </div>
      </div>
    </div>
  );
};
