
import React, { useState } from 'react';
import { X, Copy, Check, Download } from 'lucide-react';
import { LiveCode } from '../types';

interface PromotionModalProps {
  code: LiveCode;
  onClose: () => void;
}

export const PromotionModal: React.FC<PromotionModalProps> = ({ code, onClose }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code.mainUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl relative animate-in fade-in zoom-in duration-200">
        <div className="bg-blue-600 p-4 rounded-t-2xl flex items-center justify-between text-white">
          <h3 className="font-bold text-lg">推广码</h3>
          <button onClick={onClose} className="hover:bg-white/20 p-1 rounded-full transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-8 flex flex-col items-center">
          <div className="bg-white p-4 rounded-xl border-2 border-gray-100 shadow-sm mb-6">
            <div className="w-48 h-48 bg-gray-50 flex items-center justify-center overflow-hidden">
               {/* Simplified QR Placeholder */}
               <img 
                 src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(code.mainUrl)}`} 
                 alt="Main QR" 
                 className="w-full h-full"
               />
            </div>
          </div>

          <div className="w-full flex items-center mb-8 border border-gray-200 rounded-lg overflow-hidden focus-within:ring-2 focus-within:ring-blue-500">
            <div className="flex-1 px-3 py-3 bg-gray-50 text-gray-500 text-sm truncate font-mono">
              {code.mainUrl}
            </div>
            <button 
              onClick={handleCopy}
              className={`flex items-center space-x-1 px-4 py-3 font-medium transition-colors ${
                copied ? 'bg-green-500 text-white' : 'bg-blue-600 text-white hover:bg-blue-700'
              }`}
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? '已复制' : '复制链接'}</span>
            </button>
          </div>

          <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold text-lg transition-transform active:scale-[0.98] flex items-center justify-center gap-2">
            <Download className="w-5 h-5" />
            下载二维码图片
          </button>
        </div>

        {/* Floating Success Toast when copied */}
        {copied && (
          <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-white/95 px-4 py-2 rounded-full shadow-lg border border-green-100 flex items-center space-x-2 animate-in slide-in-from-top-4">
             <div className="w-5 h-5 rounded-full bg-green-500 flex items-center justify-center">
               <Check className="w-3 h-3 text-white" />
             </div>
             <span className="text-green-700 font-medium">链接复制成功</span>
          </div>
        )}
      </div>
    </div>
  );
};
