
export enum DistributionMode {
  THRESHOLD = 'THRESHOLD',
  RANDOM = 'RANDOM',
  FIXED = 'FIXED'
}

export interface SubCode {
  id: string;
  qrUrl: string;
  threshold: number;
  currentPv: number;
  weight: number;
  status: 'enabled' | 'disabled';
}

export interface LiveCode {
  id: string;
  name: string;
  status: 'running' | 'paused';
  distributionMode: DistributionMode;
  totalPv: number;
  subCodes: SubCode[];
  mainUrl: string;
}

export interface DashboardStats {
  totalPv: number;
  activeCodes: number;
  newToday: number;
  conversionRate: string;
}
